

CREATE TABLE [dbo].[Employee](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[EmpID] [varchar](11) NOT NULL,
	[FirstName] [varchar](20) NOT NULL,
	[MiddleName] [varchar](20) NULL,
	[LastName] [varchar](20) NOT NULL,
	[CertificateDOB] [date] NOT NULL,
	[ActualBOD] [date] NULL,
	[DOJ] [datetime] NOT NULL,
	[Gender] [tinyint] NOT NULL,
	[ReportingManagerid] [varchar](11) NOT NULL,
	[OfficeLocation] [varchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
	[CompanyEmailId] [varchar](30) NOT NULL,
	[PersonalEmailId] [varchar](30) NOT NULL,
	[SeperatedDate] [datetime] NULL,
	[MaritalStatus] [tinyint] NOT NULL,
	[CreatedBy] [bigint] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedBy] [bigint] NULL,
	[ModifiedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UC_Employee] UNIQUE NONCLUSTERED 
(
	[EmpID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

