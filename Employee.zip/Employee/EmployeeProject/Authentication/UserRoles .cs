﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeProject.Authentication
{
    public class UserRoles
    {
        public const string Admin = "SuperAdmin";
        public const string User = "User";
    }
}
