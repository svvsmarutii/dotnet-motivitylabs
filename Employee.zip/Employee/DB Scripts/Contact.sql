
CREATE TABLE [dbo].[Contact](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeId] [bigint] NOT NULL,
	[MobileCountryCode] [tinyint] NOT NULL,
	[Mobile] [bigint] NOT NULL,
	[AlternateMobileCountryCode] [tinyint] NULL,
	[AlternateMobile] [bigint] NULL,
	[WorkNumberCountryCode] [tinyint] NULL,
	[WorkNumber] [bigint] NULL,
	[WorkExtension] [tinyint] NULL,
	[HomeCountryCode] [tinyint] NULL,
	[HomeNumber] [bigint] NULL,
	[HomeExtension] [tinyint] NULL,
	[CompanyMobileCountryCode] [tinyint] NULL,
	[CompanyMobile] [bigint] NULL,
	[Active] [bit] NOT NULL,
	[CreatedBy] [bigint] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedBy] [bigint] NULL,
	[ModifiedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Contact]  WITH CHECK ADD FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employee] ([ID])
GO

