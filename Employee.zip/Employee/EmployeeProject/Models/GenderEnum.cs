﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeProject.Models
{
    public enum GenderEnum:byte
    {
      Male=0,
      Female=1,     
    }
}
